package Problem_Statement6_2;

	import java.util.Hashtable;
	import java.util.Scanner;
	
	public class Product {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Hashtable<String,String> hs=new Hashtable<String,String>();
		System.out.println("enter the product id and name:");
		for(int i=0;i<3;i++)
		{
		hs.put(sc.next(),sc.next());
		}
		System.out.println("the product list is:");
		System.out.println(hs);
		System.out.println("enter the product id to be removed:");
		String id = sc.next();
		hs.remove(id);
		System.out.println("item removed");
		System.out.println("the product list is:");
		System.out.println(hs.toString());
		System.out.println("enter the product id to be searched:");
		String sid=sc.next();
		if(hs.containsKey(sid))
		{
			System.out.println(hs.get(sid));
		}
		else {
			System.out.println("do not exist");
		}
	}
	}

